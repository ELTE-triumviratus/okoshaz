//LegKondi

const temperatureButton = document.getElementById("temperatureButton");
const temperatureDisplay = document.getElementById("temperatureDisplay");

let currentTemperature = 21;
let targetTemperature = 31;
let temperatureInterval;

temperatureButton.addEventListener("click", function () {
    if (temperatureInterval) {
        clearInterval(temperatureInterval);
        temperatureInterval = null;
    } else {
        temperatureInterval = setInterval(updateTemperature, 500);
    }
});

function updateTemperature() {
    if (currentTemperature < targetTemperature) {
        currentTemperature++;
    } else if (currentTemperature > targetTemperature) {
        currentTemperature--;
    } else {
        targetTemperature = (targetTemperature === 31) ? 21 : 31;
    }

    temperatureDisplay.textContent = `${currentTemperature}°C`;

    if (currentTemperature === 31 || currentTemperature === 21) {
        clearInterval(temperatureInterval);
        temperatureInterval = null;
    }
}

//ElektronyosRadiator

const temperatureButton2 = document.getElementById("temperatureButton2");
const temperatureDisplay2 = document.getElementById("temperatureDisplay2");

let currentTemperature2 = 35;
let targetTemperature2 = 10;
let temperatureInterval2;

temperatureButton2.addEventListener("click", function () {
    if (temperatureInterval2) {
        clearInterval(temperatureInterval2);
        temperatureInterval2 = null;
    } else {
        temperatureInterval2 = setInterval(updateTemperature2, 100);
    }
});

function updateTemperature2() {
    if (currentTemperature2 < targetTemperature2) {
        currentTemperature2++;
    } else if (currentTemperature2 > targetTemperature2) {
        currentTemperature2--;
    } else {
        targetTemperature2 = (targetTemperature2 === 35) ? 10 : 35;
    }

    temperatureDisplay2.textContent = `${currentTemperature2}°C`;

    if (currentTemperature2 === 35 || currentTemperature2 === 10) {
        clearInterval(temperatureInterval2);
        temperatureInterval2 = null;
    }
}

//PorZsivoe

const roombaButton = document.getElementById("roombaButton");
const roomba = document.createElement("img");
roomba.src = "https://pngimg.com/d/robot_vacuum_PNG34.png";
roomba.alt = "Roomba";
roomba.classList.add("roomba");
document.body.appendChild(roomba);

roombaButton.addEventListener("click", function () {
    roomba.style.transform = "translateX(calc(-100% - 1300px)) scaleX(-1)";
});

roomba.addEventListener("transitionend", function () {
    roomba.style.transform = "translateX(0) scaleX(1)";
});