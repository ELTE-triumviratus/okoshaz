//ParaElszivo

document.addEventListener("DOMContentLoaded", function () {
    const steam1 = document.getElementById("steam1");
    const steam2 = document.getElementById("steam2");
    const slideButton = document.getElementById("slideButton");

    let isSlidUp = false;

    slideButton.addEventListener("click", function () {
        if (isSlidUp) {
            steam1.style.bottom = "420px";
            steam2.style.bottom = "420px";
        } else {
            steam1.style.bottom = "666px";
            steam2.style.bottom = "666px";
        }

        isSlidUp = !isSlidUp;
    });
});

//LegKondi

const temperatureButton = document.getElementById("temperatureButton");
const temperatureDisplay = document.getElementById("temperatureDisplay");

let currentTemperature = 21;
let targetTemperature = 31;
let temperatureInterval;

temperatureButton.addEventListener("click", function () {
    if (temperatureInterval) {
        clearInterval(temperatureInterval);
        temperatureInterval = null;
    } else {
        temperatureInterval = setInterval(updateTemperature, 500);
    }
});

function updateTemperature() {
    if (currentTemperature < targetTemperature) {
        currentTemperature++;
    } else if (currentTemperature > targetTemperature) {
        currentTemperature--;
    } else {
        targetTemperature = (targetTemperature === 31) ? 21 : 31;
    }

    temperatureDisplay.textContent = `${currentTemperature}°C`;

    if (currentTemperature === 31 || currentTemperature === 21) {
        clearInterval(temperatureInterval);
        temperatureInterval = null;
    }
}

//HutoSzekreny

const temperatureButton2 = document.getElementById("temperatureButton2");
const temperatureDisplay2 = document.getElementById("temperatureDisplay2");

let currentTemperature2 = 10;
let targetTemperature2 = -15;
let temperatureInterval2;

temperatureButton2.addEventListener("click", function () {
    if (temperatureInterval2) {
        clearInterval(temperatureInterval2);
        temperatureInterval2 = null;
    } else {
        temperatureInterval2 = setInterval(updateTemperature2, 1000);
    }
});

function updateTemperature2() {
    if (currentTemperature2 < targetTemperature2) {
        currentTemperature2++;
    } else if (currentTemperature2 > targetTemperature2) {
        currentTemperature2--;
    } else {
        targetTemperature2 = (targetTemperature2 === 10) ? -15 : 10;
    }

    temperatureDisplay2.textContent = `${currentTemperature2}°C`;

    if (currentTemperature2 === 10 || currentTemperature2 === -15) {
        clearInterval(temperatureInterval2);
        temperatureInterval2 = null;
    }
}

//PorZsivoe

const roombaButton = document.getElementById("roombaButton");
const roomba = document.createElement("img");
roomba.src = "https://pngimg.com/d/robot_vacuum_PNG34.png";
roomba.alt = "Roomba";
roomba.classList.add("roomba");
document.body.appendChild(roomba);

roombaButton.addEventListener("click", function () {
    roomba.style.transform = "translateX(calc(-100% - 1300px)) scaleX(-1)";
});

roomba.addEventListener("transitionend", function () {
    roomba.style.transform = "translateX(0) scaleX(1)";
});