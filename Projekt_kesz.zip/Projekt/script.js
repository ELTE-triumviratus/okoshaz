const temperatureButton = document.getElementById("temperatureButton");
const temperatureDisplay = document.getElementById("temperatureDisplay");

let currentTemperature = 21;
let targetTemperature = 31;
let temperatureInterval;

temperatureButton.addEventListener("click", function () {
    if (temperatureInterval) {
        clearInterval(temperatureInterval);
        temperatureInterval = null;
    } else {
        temperatureInterval = setInterval(updateTemperature, 500);
    }
});

function updateTemperature() {
    if (currentTemperature < targetTemperature) {
        currentTemperature++;
    } else if (currentTemperature > targetTemperature) {
        currentTemperature--;
    } else {
        targetTemperature = (targetTemperature === 31) ? 21 : 31;
    }

    temperatureDisplay.textContent = `${currentTemperature}°C`;

    if (currentTemperature === 31 || currentTemperature === 21) {
        clearInterval(temperatureInterval);
        temperatureInterval = null;
    }
}